package com.example.quiz2juangarcia;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.example.quiz2juangarcia.databinding.ActivityMainBinding;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String URL = "https://digimon-api.vercel.app/api/digimon";

    private ActivityMainBinding binding;
    private final List<Digimon> lista = new ArrayList<>();
    private DigimonAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.enableEdgeToEdge(getWindow());

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.main, (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        adapter = new DigimonAdapter(lista);
        binding.rvDigimon.setLayoutManager(new LinearLayoutManager(this));
        binding.rvDigimon.setAdapter(adapter);

        cargarDigimon();
    }

    private void cargarDigimon() {
        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET, URL, null,
                response -> {
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject o = response.getJSONObject(i);
                            lista.add(new Digimon(
                                    o.getString("name"),
                                    o.getString("img"),
                                    o.getString("level")));
                        }
                        adapter.notifyDataSetChanged();
                    } catch (JSONException e) {
                        Log.e("Digidex", "Error al leer el json", e);
                    }
                },
                error -> {
                    Log.e("Digidex", "Error de red", error);
                    Toast.makeText(this, "No se pudo cargar la Digidex", Toast.LENGTH_LONG).show();
                }
        );
        queue.add(request);
    }
}