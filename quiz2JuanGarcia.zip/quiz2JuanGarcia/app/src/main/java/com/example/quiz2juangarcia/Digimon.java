package com.example.quiz2juangarcia;

public class Digimon {
    private final String name;
    private final String img;
    private final String level;

    public Digimon(String name, String img, String level) {
        this.name = name;
        this.img = img;
        this.level = level;
    }

    public String getName() { return name; }
    public String getImg() { return img; }
    public String getLevel() { return level; }
}
