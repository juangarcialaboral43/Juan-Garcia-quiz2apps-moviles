package com.example.quiz2juangarcia;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.quiz2juangarcia.databinding.ItemDigimonBinding;

import java.util.List;

public class DigimonAdapter extends RecyclerView.Adapter<DigimonAdapter.ViewHolder> {

    private final List<Digimon> lista;

    public DigimonAdapter(List<Digimon> lista) {
        this.lista = lista;
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        final ItemDigimonBinding b;

        ViewHolder(ItemDigimonBinding b) {
            super(b.getRoot());
            this.b = b;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemDigimonBinding b = ItemDigimonBinding.inflate(
                LayoutInflater.from(parent.getContext()), parent, false);
        return new ViewHolder(b);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Digimon d = lista.get(position);
        holder.b.tvName.setText(d.getName());
        holder.b.tvLevel.setText("Nivel: " + d.getLevel());

        Glide.with(holder.itemView.getContext())
                .load(d.getImg())
                .error(android.R.drawable.ic_menu_gallery)
                .into(holder.b.imgDigimon);
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }
}
